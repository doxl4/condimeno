import os
os.system("pip install discord")
os.system("pip install ping3")
os.system("pip install aiohttp")
os.system("pip install asyncio")
os.system("pip install random")
os.system("pip install requests")
os.system("pip install psutil")
os.system("pip install threading")

